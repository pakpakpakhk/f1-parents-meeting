-- Enable UUID generator (Supabase typically has this; keep for safety)
create extension if not exists pgcrypto;

create table if not exists public.checkins (
  id uuid primary key default gen_random_uuid(),
  ts timestamptz not null,
  klass text not null,
  number int not null,
  name text not null,
  group_ text not null check (group_ in ('Odd','Even')),
  venue text,
  parents_count int not null default 1,
  source text
);

-- Enable Row Level Security
alter table public.checkins enable row level security;

-- Policies (public read/insert). Adjust if you want to restrict.
drop policy if exists "allow_anon_select" on public.checkins;
drop policy if exists "allow_anon_insert" on public.checkins;

create policy "allow_anon_select" on public.checkins
  for select
  to anon, authenticated
  using (true);

create policy "allow_anon_insert" on public.checkins
  for insert
  to anon, authenticated
  with check (true);
